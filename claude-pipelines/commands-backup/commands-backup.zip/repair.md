---
description: Repair a request that has failing tests or validation issues
argument-hint: REQ-XXX [--all-blockers]
allowed-tools: Task, Read, Glob, Grep, Bash, Write, Edit, TodoWrite
---

# Request Repair Command

You are a repair coordinator that fixes requests with failing tests or validation issues. Your goal is to get blocking requests from "implemented but failing" to "implemented and passing".

## Input: $ARGUMENTS

Parse the input to determine what to repair:

### Single Request: `REQ-E04-001`
Repair the specified request.

### All Blockers: `--all-blockers` or `all`
Find all requests that are blocking others due to test failures and repair them in order.

### From Pipeline State: `--from-state [path]`
Read the pipeline state file and identify requests needing repair.

## Repair Workflow

### For Single Request

1. **Locate the request**
   ```bash
   ls docs/ | grep -i "REQ-E04-001"
   ```

2. **Launch repair agent**
   Use the Task tool with `subagent_type="99-repair-agent"`:
   ```
   Repair REQ-E04-001.

   Find the detailed spec at docs/REQ-E04-001-*-detailed.md.
   Run the tests to identify failures, diagnose the issue,
   apply minimal fixes, and verify tests pass.
   ```

3. **Report results**
   After agent completes, summarize:
   - Tests before/after
   - Fixes applied
   - Whether request is now unblocked

### For All Blockers

1. **Identify blocking requests**
   Read the pipeline state or scan for requests with `tests_passed: false`:
   ```bash
   grep -l "tests_passed.*false" pipelines-execution/*-state.json
   ```

2. **Determine repair order**
   Repair in dependency order - fix requests that have no dependencies first.

3. **Repair each request**
   Loop through blockers, invoking repair agent for each.

4. **Final summary**
   Report overall results:
   - Total blockers found
   - Successfully repaired
   - Still failing
   - Recommendations

## Examples

`/repair REQ-E04-001`
→ Repair single request

`/repair --all-blockers`
→ Find and repair all blocking requests

`/repair REQ-E04-001 REQ-E04-002 REQ-E04-005`
→ Repair multiple specific requests

## Error Handling

If repair fails after multiple attempts:
1. Report what was tried
2. Show the specific error
3. Suggest manual investigation needed
4. Move to next request (if batch mode)

## Output Format

After repair:

```
## Repair Results

### REQ-E04-001: Create localization types file
**Status:** ✅ FIXED

| Metric | Before | After |
|--------|--------|-------|
| Tests Passing | 12/15 | 15/15 |
| Type Errors | 2 | 0 |

**Fixes Applied:**
1. Fixed import path in `src/types/l10n.ts`
2. Added missing export to barrel file

---

### REQ-E04-002: Create guest language utility
**Status:** ⚠️ PARTIALLY FIXED

...
```

---
Created: 2026-01-23
